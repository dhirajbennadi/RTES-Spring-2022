#! /bin/sh

make op1
