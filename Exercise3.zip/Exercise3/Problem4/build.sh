#! /bin/sh

make op1
make op2