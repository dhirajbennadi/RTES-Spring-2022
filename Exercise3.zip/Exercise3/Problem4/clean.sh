#! /bin/sh

make clean